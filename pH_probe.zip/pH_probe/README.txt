to use the code you must install the library.
to install the library you can follow this pdf: https://www.atlas-scientific.com/_files/code/gravity-pH-ardunio-code.pdf

if you are too lazy to open it, here is the plain text instructions:
1. drag atlas_gravity.zip to program files (x86) -> arduino -> libraries
2. open arduino IDE and on the top drop down menu select Sketch -> Include Library -> Add .zip Library, then navigate to atlas_gravity.zip and select it.

now you can run pH_code.ino. 

if you lose it, its the example code loaded with the library.
to retrieve the example code, in the arduino IDE:
on the top drop down menu select: File > Examples > Atlas_gravity > Examples > pH_grav_example